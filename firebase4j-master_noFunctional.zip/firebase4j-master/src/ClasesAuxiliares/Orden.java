/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import java.util.ArrayList;

/**
 *
 * @author Luis A. Sarango-Parrales
 */
public class Orden {

    private String Descripcion, FechaHoraAsistencia;
    private ArrayList<String> Examenes;//OrdenParametros

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getFechaHoraAsistencia() {
        return FechaHoraAsistencia;
    }

    public void setFechaHoraAsistencia(String FechaHoraAsistencia) {
        this.FechaHoraAsistencia = FechaHoraAsistencia;
    }

    public ArrayList<String> getExamenes() {
        return Examenes;
    }

    public void setExamenes(ArrayList<String> Examenes) {
        this.Examenes = Examenes;
    }

    @Override
    public String toString() {
        return "Orden{" + "Descripcion=" + Descripcion + ", FechaHoraAsistencia=" + FechaHoraAsistencia + ", Examenes=" + Examenes + '}';
    }

 }
