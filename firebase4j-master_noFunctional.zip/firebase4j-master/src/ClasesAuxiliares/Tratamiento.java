/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import java.util.ArrayList;

/**
 *
 * @author Luis A. Sarango-Parrales
 */
public class Tratamiento {

    private String medicacion, indicaciones, fechaInicio, fechaFin;

    private ArrayList<Horario> horarios;

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getMedicacion() {
        return medicacion;
    }

    public void setMedicacion(String medicacion) {
        this.medicacion = medicacion;
    }

    public String getIndicaciones() {
        return indicaciones;
    }

    public void setIndicaciones(String indicaciones) {
        this.indicaciones = indicaciones;
    }

    public ArrayList<Horario> getHorarios() {
        return horarios;
    }

    public void setHorarios(ArrayList<Horario> horarios) {
        this.horarios = horarios;
    }

    @Override
    public String toString() {
        return "Tratamiento{" + "fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + ", medicacion=" + medicacion + ", indicaciones=" + indicaciones + ", horarios=" + horarios + '}';
    }

}
