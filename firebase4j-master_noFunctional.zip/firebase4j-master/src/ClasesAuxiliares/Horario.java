/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import java.util.ArrayList;

public class Horario {

    private String hora, condicionComida;
    private ArrayList acciones = new ArrayList();

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getCondicionComida() {
        return condicionComida;
    }

    public void setCondicionComida(String condicionComida) {
        this.condicionComida = condicionComida;
    }

    public ArrayList getAcciones() {
        return acciones;
    }

    public void setAcciones(ArrayList acciones) {
        this.acciones = acciones;
    }

    @Override
    public String toString() {
        return "Horario{" + "hora=" + hora + ", condicionComida=" + condicionComida + ", acciones=" + acciones + '}';
    }
}
