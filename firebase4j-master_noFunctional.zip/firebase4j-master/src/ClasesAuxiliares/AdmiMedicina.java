/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesAuxiliares;

import java.util.ArrayList;

/**
 *
 * @author Luis A. Sarango-Parrales
 */
public class AdmiMedicina {

    protected String tipo;
    private ArrayList<Producto> medicamentos;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {

        this.tipo = tipo;

    }

    public AdmiMedicina() {
        setTipo("AdmiMedicina");
    }

    public ArrayList<Producto> getMedicamentos() {
        return medicamentos;
    }

    public void setMedicamentos(ArrayList<Producto> medicamentos) {
        this.medicamentos = medicamentos;
    }

}
