/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FamiliaOperaciones;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import net.thegreshams.firebase4j.error.FirebaseException;
import net.thegreshams.firebase4j.error.JacksonUtilityException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

/**
 *
 * @author Luis A. Sarango-Parrales
 */
public interface IConsultaDAO {
    
    public void create(ConsultaMedica consulta) throws Exception,FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException;
    public ArrayList<ConsultaMedica>  readAllConsultasPaciente(String cedulaNombre)  throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException;
    public ArrayList<ConsultaMedica> readAllConsultasFecha(LocalDate fecha) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException;
    
}

