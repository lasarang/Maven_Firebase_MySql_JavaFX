/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FamiliaOperaciones;

import ClasesAuxiliares.AdmiMedicina;
import ClasesAuxiliares.Horario;
import ClasesAuxiliares.Orden;
import ClasesAuxiliares.Producto;
import ClasesAuxiliares.SignosVitales;
import ClasesAuxiliares.Tratamiento;
import Extra.Validate;
import MySQl.Conexion;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.thegreshams.firebase4j.error.FirebaseException;
import net.thegreshams.firebase4j.error.JacksonUtilityException;
import net.thegreshams.firebase4j.model.FirebaseResponse;
import net.thegreshams.firebase4j.service.Firebase;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

/**
 *
 * @author Luis A. Sarango-Parrales
 */
public class ConsultaDAOImpl implements IConsultaDAO {

    private final Conexion conexion = Conexion.getInstancia();
    private final Connection connection = conexion.getConnection();
    private Firebase firebase;
    private FirebaseResponse response;
    private final Validate validate = new Validate();
    private CallableStatement cs, cs2, cs3, cs4, cs5, cs6;
    private PreparedStatement ps;
    private ResultSet rs, rs2, rs3, rs4, rs5, rs6;
    private Tratamiento tratamiento;
    private Horario horario;
    private AdmiMedicina am;
    private Producto medicamento;
    private ArrayList<String> parametros;
    private ArrayList<Horario> horarios;
    private ArrayList<Producto> medicamentos;
    private ArrayList<ConsultaMedica> consultasObtenidas;
    private ArrayList<String[]> proximasConsultas;
    private HashMap<String, ArrayList<String[]>> diagnosticos;
    private ConsultaMedica cm;
    private SignosVitales signos;
    private Tratamiento tm, tm2;
    private Orden ord;
    private LinkedHashMap<String, Object> mapaConsulta, mapaCitas, mapaInterno;

    @Override
    public void create(ConsultaMedica consulta) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException {
        tratamiento = consulta.getTratamiento();
        ord = consulta.getOrden();

        //Consulta: Operacion mysql
        cs = connection.prepareCall("{CALL createOperacion(?, ?, ?, ?)}");
        cs.setInt(1, consulta.getIdPersona1());
        cs.setInt(2, consulta.getIdPersona2());
        cs.setObject(3, consulta.getFechaHoraInicio());
        cs.setString(4, consulta.getTipo());
        cs.executeQuery();
        cs.close();

        //Consulta: ConsultaMedica mysql
        cs = connection.prepareCall("{CALL createConsulta(?, ?, ?, ?, ?, ?, ?, ?)}");
        cs.setInt(1, consulta.getIdOperacion());
        cs.setObject(2, consulta.getFechaHoraFin());
        cs.setString(3, consulta.getMotivos());
        cs.setString(4, consulta.getExamenFisico());
        cs.setString(5, consulta.getProcedimiento());
        cs.setBoolean(6, consulta.isEmergency());
        cs.setString(7, consulta.getAcompañante());
        cs.setString(8, consulta.getRelacion());
        cs.executeQuery();
        cs.close();

        //Consulta: SignosVitales mysql
        signos = consulta.getSignosVitales();
        cs = connection.prepareCall("{CALL createSignosVitales(?, ?, ?, ?, ?, ?, ?, ?, ?)}");
        cs.setInt(1, consulta.getIdConsulta());
        cs.setDouble(2, signos.getPulso());
        cs.setDouble(3, signos.getFrecuenciaRespiratoria());
        cs.setDouble(4, signos.getPresionSistolica());
        cs.setDouble(5, signos.getPresionDiastolica());
        cs.setDouble(6, signos.getSaturacionOxigeno());
        cs.setDouble(7, signos.getTemperatura());
        cs.setDouble(8, signos.getTalla());
        cs.setDouble(9, signos.getPeso());

        cs.executeQuery();
        cs.close();

        //Consulta: Diagnosticos mysql
        //Antecedentes personales
        for (String[] personales : consulta.getDiagnosticos().get("Personales")) {
            cs = connection.prepareCall("{CALL createDiagnostico(?, ?, ?, ?)}");
            cs.setInt(1, consulta.getIdConsulta());
            cs.setString(4, "Personal");//TipoAntecedente
            cs.setString(2, personales[0]);//Diagnostico
            cs.setString(3, personales[1]);//CIE10
            cs.executeQuery();
            cs.close();
        }
        //Antecedentes familiares 
        for (String[] familiares : consulta.getDiagnosticos().get("Familiares")) {
            cs = connection.prepareCall("{CALL createDiagnostico(?, ?, ?, ?)}");
            cs.setInt(1, consulta.getIdConsulta());
            cs.setString(4, "Familiar");//TipoAntecedente
            cs.setString(2, familiares[0]);//Diagnostico
            cs.setString(3, familiares[1]);//CIE10
            cs.executeQuery();
            cs.close();
        }

        //Consulta: citas medicas  Firebase
        mapaCitas = new LinkedHashMap<String, Object>();
        for (String[] proxima : consulta.getProximasConsultas()) {
            mapaCitas.put(proxima[0], proxima[1]);  //Fecha-Descripcion
        }

        //Consulta: Orden  Firebase
        //Consulta: Tratamiento Firebase
        mapaInterno = new LinkedHashMap<String, Object>();
        mapaInterno.put("Orden", ord);
        mapaInterno.put("Citas", mapaCitas);
        mapaInterno.put("Tratamiento", tratamiento);

        mapaConsulta = new LinkedHashMap<String, Object>();
        mapaConsulta.put(consulta.getFechaHoraInicio().toString(), mapaInterno);

        // create the firebase
        firebase = new Firebase("https://medicalcenter-baa32.firebaseio.com");

        response = firebase.put(validate.obtenerIdPersonaNroHistoria(consulta.getIdPersona2()), mapaConsulta);

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        conexion.desconectar();

        System.out.println("Creación exitosa de la consulta!");

    }

    private void createHorarios(Tratamiento tratamiento) throws Exception {

    }

    @Override
    public ArrayList<ConsultaMedica> readAllConsultasPaciente(String cedulaNombre) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException {

        consultasObtenidas = new ArrayList<ConsultaMedica>();

        int nroHistoria;
        if (Validate.isNumeric(cedulaNombre)) {
            nroHistoria = validate.obtenerNroHistoriaCedula(cedulaNombre);
        } else {
            nroHistoria = validate.obtenerNroHistoriaNombre(cedulaNombre);
        }

        cs = connection.prepareCall("{CALL readNroHistoriaConsulta(?)}");
        cs.setInt(1, nroHistoria);
        rs = cs.executeQuery();

        String cedulaPaciente = validate.obtenerIdPersonaNroHistoria(nroHistoria);

        //Operacion-ConsultaMedica
        while (rs.next()) {
            cm = new ConsultaMedica();

            int idOperacion = rs.getInt("idOperacion"),
                    idPersona1 = rs.getInt("idPerson1"),
                    idPersona2 = rs.getInt("idPerson2"),
                    idConsulta = rs.getInt("idConsulta");

            String tipo = rs.getString("Tipo"),
                    motivos = rs.getString("Motivos"),
                    examenFisico = rs.getString("ExamenFisico"),
                    procedimiento = rs.getString("Procedimiento"),
                    acompañante = rs.getString("Acompañante"),
                    relacion = rs.getString("Relacion");
            Timestamp fechaHoraInicio = (Timestamp) rs.getObject("FechaHoraInicio"),
                    fechaHoraFin = (Timestamp) rs.getObject("FechaHoraFin");
            boolean emergencia = rs.getBoolean("esEmergencia");

            cm.setIdOperacion(idOperacion);
            cm.setTipo(tipo);
            cm.setIdMedicalVisit(idOperacion);
            cm.setIdConsulta(idConsulta);
            cm.setIdPersona1(idPersona1);
            cm.setIdPersona2(idPersona2);
            cm.setCedulaPaciente(cedulaPaciente);
            cm.setFechaHoraInicio(fechaHoraInicio.toLocalDateTime());
            cm.setFechaHoraFin(fechaHoraFin.toLocalDateTime());
            cm.setMotivos(motivos);
            cm.setExamenFisico(examenFisico);
            cm.setProcedimiento(procedimiento);
            cm.setEmergency(emergencia);
            cm.setAcompañante(acompañante);
            cm.setRelacion(relacion);
            cm.setSignosVitales(readSignosVitales(idConsulta));
            cm.setOrden(readOrden(cedulaPaciente, fechaHoraInicio.toLocalDateTime().toString()));
            cm.setProximasConsultas(readCitas(cedulaPaciente, fechaHoraInicio.toLocalDateTime().toString()));
            cm.setDiagnosticos(readDiagnosticos(idConsulta));

            consultasObtenidas.add(cm);
        }

        conexion.desconectar();
        return consultasObtenidas;

    }

    // mysql
    private SignosVitales readSignosVitales(int idConsulta) throws Exception {

        signos = new SignosVitales();
        cs2 = connection.prepareCall("{CALL readConsultaSignosVitales(?)}");
        cs2.setInt(1, idConsulta);
        rs2 = cs2.executeQuery();
        rs2.next();
        int idSignosVitales = rs2.getInt("idSignosVitales");
        double pulso = rs2.getDouble("Pulso"),
                frecuenciaRespiratoria = rs2.getDouble("FrecuenciaRespiratoria"),
                presionSistolica = rs2.getDouble("PresionSistolica"),
                presionDiastolica = rs2.getDouble("PresionDiastolica"),
                saturacionOxigeno = rs2.getDouble("SaturacionOxigeno"),
                temperatura = rs2.getDouble("Temperatura"),
                talla = rs2.getDouble("Talla"),
                peso = rs2.getDouble("Peso");

        signos.setIdSignosVitales(idSignosVitales);
        signos.setIdVitalSigns(idConsulta);
        signos.setPulso(pulso);
        signos.setFrecuenciaRespiratoria(frecuenciaRespiratoria);
        signos.setPresionSistolica(presionSistolica);
        signos.setPresionDiastolica(presionDiastolica);
        signos.setSaturacionOxigeno(saturacionOxigeno);
        signos.setTemperatura(temperatura);
        signos.setTalla(talla);
        signos.setPeso(peso);

        return signos;
    }

    //mysql 
    private HashMap<String, ArrayList<String[]>> readDiagnosticos(int idConsulta) throws Exception {
        diagnosticos = new HashMap<String, ArrayList<String[]>>();
        diagnosticos.put("Personales", new ArrayList<String[]>());
        diagnosticos.put("Familiares", new ArrayList<String[]>());

        cs2 = connection.prepareCall("{CALL readConsultaDiagnosticos(?)}");
        cs2.setInt(1, idConsulta);
        rs2 = cs2.executeQuery();

        while (rs2.next()) {
            String diagnostico = rs2.getString("Diagnostico"),
                    cie10 = rs2.getString("CIE10"),
                    tipoAntecedente = rs2.getString("TipoAntecedente");
            String[] d = {diagnostico, cie10};
            if (tipoAntecedente.equals("Personal")) {
                (diagnosticos.get("Personales")).add(d);
            } else if (tipoAntecedente.equals("Familiar")) {
                (diagnosticos.get("Familiares")).add(d);
            }

        }

        return diagnosticos;
    }

    // Firebase
    private ArrayList<String[]> readCitas(String cedulaPaciente, String fechaConsulta) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException {
        proximasConsultas = new ArrayList<String[]>();
        firebase = new Firebase("https://medicalcenter-baa32.firebaseio.com");
        response = firebase.get("/" + cedulaPaciente.trim() + "/" + fechaConsulta.trim() + "/Citas");

        Map<String, Object> mapa = response.getBody();
        for (String clave : mapa.keySet()) {
            String[] pc = {clave, (String) mapa.get(clave)};
            proximasConsultas.add(pc);

        }

        return proximasConsultas;

    }

    // Firebase
    private Orden readOrden(String cedulaPaciente, String fechaConsulta) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException {
        ord = new Orden();
        firebase = new Firebase("https://medicalcenter-baa32.firebaseio.com");

        response = firebase.get("/" + cedulaPaciente.trim() + "/" + fechaConsulta.trim() + "/Orden");

        Map<String, Object> mapa = response.getBody();

        ArrayList<String> exams = (ArrayList<String>) mapa.get("examenes");

        ord.setExamenes(exams);
        ord.setDescripcion((String) mapa.get("descripcion"));
        ord.setFechaHoraAsistencia((String) mapa.get("fechaHoraAsistencia"));

        return ord;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public ArrayList<ConsultaMedica> readAllConsultasFecha(LocalDate fecha) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException {

        consultasObtenidas = new ArrayList<ConsultaMedica>();
        cs = connection.prepareCall("{CALL readFechaConsulta(?)}");
        cs.setObject(1, fecha);
        rs = cs.executeQuery();

        //Operacion-ConsultaMedica
        while (rs.next()) {
            cm = new ConsultaMedica();
            ord = new Orden();
            tm = new Tratamiento();
            int idOperacion = rs.getInt("idOperacion"),
                    idPersona1 = rs.getInt("idPerson1"),
                    idPersona2 = rs.getInt("idPerson2"),
                    idConsulta = rs.getInt("idConsulta");

            String tipo = rs.getString("Tipo"),
                    motivos = rs.getString("Motivos"),
                    examenFisico = rs.getString("ExamenFisico"),
                    procedimiento = rs.getString("Procedimiento"),
                    acompañante = rs.getString("Acompañante"),
                    relacion = rs.getString("Relacion");
            Timestamp fechaHoraInicio = (Timestamp) rs.getObject("FechaHoraInicio"),
                    fechaHoraFin = (Timestamp) rs.getObject("FechaHoraFin");
            boolean emergencia = rs.getBoolean("esEmergencia");

            cm.setIdOperacion(idOperacion);
            cm.setTipo(tipo);
            cm.setIdMedicalVisit(idOperacion);
            cm.setIdConsulta(idConsulta);
            cm.setIdPersona1(idPersona1);
            cm.setIdPersona2(idPersona2);
            cm.setFechaHoraInicio(fechaHoraInicio.toLocalDateTime());
            cm.setFechaHoraFin(fechaHoraFin.toLocalDateTime());
            cm.setMotivos(motivos);
            cm.setExamenFisico(examenFisico);
            cm.setProcedimiento(procedimiento);
            cm.setEmergency(emergencia);
            cm.setAcompañante(acompañante);
            cm.setRelacion(relacion);
            cm.setSignosVitales(readSignosVitales(idConsulta));
            cm.setProximasConsultas(readCitas(validate.obtenerIdPersonaNroHistoria(idPersona2), fechaHoraInicio.toLocalDateTime().toString()));
            cm.setOrden(readOrden(validate.obtenerIdPersonaNroHistoria(idPersona2), fechaHoraInicio.toLocalDateTime().toString()));
            cm.setDiagnosticos(readDiagnosticos(idConsulta));

            consultasObtenidas.add(cm);
        }

        conexion.desconectar();
        return consultasObtenidas;

    }

}
