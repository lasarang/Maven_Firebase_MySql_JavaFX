/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.thegreshams.firebase4j.demo;

import ClasesAuxiliares.AdmiMedicina;
import ClasesAuxiliares.Horario;
import ClasesAuxiliares.Orden;
import ClasesAuxiliares.ProductoDAOImpl;
import ClasesAuxiliares.SignosVitales;
import ClasesAuxiliares.Tratamiento;
import Extra.Validate;
import FamiliaOperaciones.ConsultaDAOImpl;
import FamiliaOperaciones.ConsultaMedica;
import FamiliaPersonas.Paciente;
import FamiliaPersonas.PacienteDAOImpl;
import MySQl.Conexion;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import net.thegreshams.firebase4j.error.FirebaseException;
import net.thegreshams.firebase4j.error.JacksonUtilityException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

/**
 *
 * @author Luis A. Sarango-Parrales
 */
public class Demo extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage stage) throws Exception {

        primaryStage = stage;
        primaryStage.setResizable(false);
        primaryStage.setTitle("Inicio");
        //iniRoottLayout();
        Parent root = FXMLLoader.load(getClass().getResource("/Pantallas/LoginFXML.fxml"));
        //muestra la escena que conitne el layout
        Scene scene = new Scene(root, 950, 520);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception, FirebaseException, JsonParseException, JsonMappingException, IOException, JacksonUtilityException {
        launch(args);
        try {
            (Conexion.getInstancia()).conectar();
            // get the base-url (ie: 'http://gamma.firebase.com/username')
            String firebase_baseUrl = "https://medicalcenter-baa32.firebaseio.com";

            PacienteDAOImpl pdao = new PacienteDAOImpl();
            ProductoDAOImpl pdtdao = new ProductoDAOImpl();
            ConsultaDAOImpl cdao = new ConsultaDAOImpl();
            Validate validate = new Validate();

            ArrayList<String> ocupaciones = new ArrayList<String>(), telefonos = new ArrayList<String>(), correos = new ArrayList<String>();
            ArrayList<String[]> domicilios = new ArrayList<String[]>();
            ocupaciones.add("Actriz");
            ocupaciones.add("Azafata");

            telefonos.add("0925354677");
            telefonos.add("22766956");

            correos.add("correo1@gmail.com");
            correos.add("correo2@hotmail.es");

            String[] s1 = {"Guayaquil", "Cdla. Las Acacias"}, s2 = {"Quito", "Plaza Fosch"};
            domicilios.add(s1);
            domicilios.add(s2);

            Paciente paciente = new Paciente();

            paciente.setIdPersona("0913499742");
            paciente.setNombre("Diana Prince");
            paciente.setGenero("Femenino");
            paciente.setFechaNacimiento(LocalDate.parse("1995-08-06"));

            paciente.setNroHistoria(Integer.parseInt(validate.ultimoId("Pacientes")) + 1);
            paciente.setCorreos(correos);
            paciente.setDomicilios(domicilios);
            paciente.setTelefonos(telefonos);
            paciente.setOcupaciones(ocupaciones);
            paciente.setEstadoCivil("Soltero");
            paciente.setTipo("Paciente");
            paciente.setGrupoSanguineo("B+");

            //pdao.create(paciente);
            //Consulta de medicamentos
            System.out.println(pdtdao.readNombre("Gluco").toString());
            System.out.println(pdtdao.readNombreLab("A", "M"));

            String cedulaDoctor = "1102371802", psw = "mesigyna";
            int idMedico = validate.esUsuarioMedico(cedulaDoctor, psw),//Validando y obteniendo el idMedico del doctor
                    idConsulta = Integer.parseInt(validate.ultimoId("ConsultasMedicas")) + 1;
            //se debe guardar aparte para no aumentar el id en los demas campos

            //Creacion de una consulta medica
            ConsultaMedica consulta = new ConsultaMedica();//Si no existe el paciente no se puede iniciar sin registrarlo primero
            consulta.setIdOperacion(Integer.parseInt(validate.ultimoId("Operaciones")) + 1);
            consulta.setIdPersona1(idMedico);//idMedico
            consulta.setIdPersona2(validate.obtenerNroHistoriaCedula("0913499742"));//nroHistoria
            consulta.setCedulaPaciente("0913499742");
            consulta.setIdConsulta(idConsulta);
            consulta.setFechaHoraInicio(LocalDateTime.parse("2018-12-29 19:44:44", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            consulta.setFechaHoraFin(LocalDateTime.parse("2018-12-29 20:30:07", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            consulta.setTipo("Consulta Medica");
            consulta.setMotivos("Dolor de cabeza y vomito");
            consulta.setAcompañante("‎Amber Heard");
            consulta.setRelacion("Compañera");
            consulta.setExamenFisico("Presenta contusiones y traumatismos");
            consulta.setProcedimiento("Se realizo una sutura profunda con microcirugia");
            consulta.setEmergency(true);

            //SignosVitales
            SignosVitales signos = new SignosVitales();
            signos.setIdSignosVitales(Integer.parseInt(validate.ultimoId("SignosVitales")));
            signos.setIdVitalSigns(idConsulta);
            signos.setPulso(80);//latidos/min
            signos.setFrecuenciaRespiratoria(14);//veces/min
            signos.setPresionSistolica(120);//mmHg
            signos.setPresionDiastolica(80);
            signos.setSaturacionOxigeno(0.95);//%
            signos.setTemperatura(37);//c
            signos.setTalla(150);//cm
            signos.setPeso(43.2);//kg

            consulta.setSignosVitales(signos);

            //Diagnosticos
            HashMap<String, ArrayList<String[]>> diagnosticos = consulta.getDiagnosticos();

            ArrayList<String[]> familiares = new ArrayList<String[]>(),
                    personales = new ArrayList<String[]>();
            String[] df1 = {"Diabetes Tipo II", "E10"}, //diagnostico, cie10
                    df2 = {"Hipertension Tipo I", "I10"},
                    df3 = {"Alzhaimer", "G30"},
                    df4 = {"Astigmatismo", "H52.2"},
                    df5 = {"Hemofilia", "D66"},
                    dp1 = {"Esquizofrenia", "E10"},
                    dp2 = {"Hepatitis B", "E10"},
                    dp3 = {"Gastritis", "E10"},
                    dp4 = {"Sinusitis", "E10"};

            familiares.add(df1);
            familiares.add(df2);
            familiares.add(df3);
            familiares.add(df4);
            familiares.add(df5);

            personales.add(dp1);
            personales.add(dp2);
            personales.add(dp3);
            personales.add(dp4);

            diagnosticos.replace("Personales", personales);
            diagnosticos.replace("Familiares", familiares);

            ArrayList<String[]> proximasConsultas = consulta.getProximasConsultas();
            String[] pc1 = {"2019-01-03", "Medicina General - MD Gregory House"}, //fecha,descripcion
                    pc2 = {"2019-01-20", "Endocrinologia - MD Gregory House"},
                    pc3 = {"2019-02-08", "Cardiologia - MD Gregory House"};

            proximasConsultas.add(pc1);
            proximasConsultas.add(pc2);
            proximasConsultas.add(pc3);

            //Orden examenes
            Orden orden = new Orden();
            orden.setFechaHoraAsistencia("2018-12-30 07:15:00");
            orden.setDescripcion("Debe acudir en ayuna con un envase de orina");

            ArrayList<String> examenes = new ArrayList<String>();
            examenes.add("Leucocitos");
            examenes.add("Hematocritos");
            examenes.add("Urea");
            examenes.add("Creatinina");

            orden.setExamenes(examenes);
            consulta.setOrden(orden);

            //Tratamiento
            Tratamiento tratamiento = new Tratamiento();

            tratamiento.setFechaInicio("2018-12-31");
            tratamiento.setFechaFin("2018-12-31");
            tratamiento.setMedicacion("Tiazolidinedionas, Sulfonilureas, Antialérgicos");
            tratamiento.setIndicaciones("Se deben tomar 2 tabletas cada doce horas una antes de la comida y otra después, así mismo debe de realizar una medición de glucosa presión arterial junto a cada toma.");

            ArrayList<Horario> horarios = new ArrayList<Horario>();

            /////////////////////////////////////////////////////////////////////////////////////////
            //1er Horario
            Horario h1 = new Horario();
            ArrayList acciones1 = new ArrayList();

            h1.setHora("07:15:00");
            h1.setCondicionComida("AntesComida");

            /////////////////////////////////////////////////////////////////////////////////////////
            AdmiMedicina am1 = new AdmiMedicina();
            am1.setMedicamentos(pdtdao.readNombre("M"));//medicamentos

            acciones1.add("MedicionGlucosa");
            acciones1.add("MedicionPA");
            acciones1.add(am1);
            h1.setAcciones(acciones1);

            horarios.add(h1);

            /////////////////////////////////////////////////////////////////////////////////////////
            //2do Horario
            Horario h2 = new Horario();
            ArrayList acciones2 = new ArrayList();

            h2.setHora("12:30:00");
            h2.setCondicionComida("AntesComida");
            //////////////////////////////////////////////////////////////////////////////////////////
            AdmiMedicina am2 = new AdmiMedicina();

            am2.setMedicamentos(pdtdao.readNombre("Gluco"));//medicamentos

            acciones2.add("MedicionGlucosa");
            acciones2.add(am2);

            h2.setAcciones(acciones2);

            horarios.add(h2);
            /////////////////////////////////////////////////////////////////////////////////////////
            //3er Horario
            Horario h3 = new Horario();
            ArrayList acciones3 = new ArrayList();
            h3.setHora("19:15:00");
            h3.setCondicionComida("DespuesComida");

            /////////////////////////////////////////////////////////////////////////////////////////
            AdmiMedicina am3 = new AdmiMedicina();

            am3.setMedicamentos(pdtdao.readNombreLab("A", "B"));//medicamentos

            acciones3.add("MedicionPA");
            acciones3.add(am3);

            h3.setAcciones(acciones3);

            horarios.add(h3);

            tratamiento.setHorarios(horarios);

            consulta.setTratamiento(tratamiento);
            /////////////////////////////////////////////////////////////////////////////////////////

            //cdao.create(consulta);
            //System.out.println(cdao.readAllConsultasPaciente("0913499742"));
            System.out.println(cdao.readAllConsultasFecha(LocalDate.parse("2018-12-29")));
            System.out.println(pdao.read("Diana Prince"));

            /////////////////////////////////////////////////////////////////////////////////////////
            //FIREBASE
            /*
            for (String s : args) {

                if (s == null || s.trim().isEmpty()) {
                    continue;
                }
                if (s.trim().split("=")[0].equals("baseUrl")) {
                    firebase_baseUrl = s.trim().split("=")[1];
                }
            }
            if (firebase_baseUrl == null || firebase_baseUrl.trim().isEmpty()) {
                throw new IllegalArgumentException("Program-argument 'baseUrl' not found but required");
            }

            // create the firebase
            Firebase firebase = new Firebase(firebase_baseUrl);

            // "DELETE" (the fb4jDemo-root)
            //FirebaseResponse response = firebase.delete();

            
        // "PUT" (test-map into the fb4jDemo-root)
        Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
        dataMap.put("root", "Valor1 del root");
        response = firebase.put(dataMap);
        System.out.println("\n\nResultado del PUT:\n" + response);
        System.out.println("\n");

        // "GET" (the fb4jDemo-root)
        response = firebase.get();
        System.out.println("\n\nResult of GET:\n" + response);
        System.out.println("\n");
        Map<String, Object> mapa = response.getBody();
        System.out.println("Mapa: " + mapa);
        System.out.println("clave: "+"root"+" valor: "+ mapa.get("root"));
        System.out.println();
        

        // "DELETE" (it's own test-node)
        dataMap = new LinkedHashMap<String, Object>();
        dataMap.put("DELETE", "This should not appear; should have been DELETED");
        response = firebase.put("test-DELETE", dataMap);

        System.out.println("\n\nResult of PUT (for the test-DELETE):\n" + response);
        response = firebase.delete("test-DELETE");
        System.out.println("\n\nResult of DELETE (for the test-DELETE):\n" + response);
        response = firebase.get("test-DELETE");
        System.out.println("\n\nResult of GET (for the test-DELETE):\n" + response);
             
            // "PUT" (test-map into a sub-node off of the fb4jDemo-root)
            FirebaseResponse response;
            Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
            Orden o = new Orden();
            o.setDescripcion("Debe acudir en ayuna con un envase de orina");
            o.setFechaHoraAsistencia("2018-12-30 07:15:00");

            ArrayList<String> Examenes = new ArrayList<String>();
            Examenes.add("Hemoglobina");
            Examenes.add("Plaquetas");

            Examenes.add("Creatinina");
            Examenes.add("Urea");

            o.setExamenes(Examenes);

            dataMap.put("Orden", o);

            
        Map<String, Object> dataMap2 = new LinkedHashMap<String, Object>();
        dataMap2.put("Sub Clave3", "Sub Value 3");
        dataMap.put("Clave 3", dataMap2);
        
        response = firebase.put("/0926688391/2018-12-29_19:44:44/Citas", dataMap);

        System.out.println("\n\nResult of PUT:\n" + response);
        System.out.println("\n");
        
        Map<String, Object> newdataMap = new LinkedHashMap<String, Object>();
        newdataMap.put("new Clave 1", "new Valor 1");
        newdataMap.put("new Clave 2", "new Valor 2");
        
        // "POST" (test-map into a sub-node off of the fb4jDemo-root) parecido al replace
        response = firebase.post("/0926688391/2018-12-29_19:44:44/Citas/Clave1", newdataMap);
        System.out.println("\n\nResult of REPLACE:\n" + response);
        System.out.println("\n");
             
            response = firebase.put("0926688391/2018-12-29_19:44:44", dataMap);

            // "GET" 
            response = firebase.get("/0926688391/2018-12-29_19:44:44/Orden");

            // Orden ord=;
            System.out.println("\n\nResult of GET Orden obj:\n" + response.getBody());
            System.out.println("\n");
             */
        } catch (Exception ex) {
            System.out.println("No se pudo conectar " + ex);
            ex.printStackTrace();
        }

    }
}
