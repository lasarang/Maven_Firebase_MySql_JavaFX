/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class RegistroP2FXMLController implements Initializable {

    @FXML
    private Label titulo;
    @FXML
    private ImageView imgaeBack;
    @FXML
    private Label LblTitulo2;
    @FXML
    private Label LblTitulo3;
    @FXML
    private Label SubTitulo1;
    @FXML
    private Button BtRegistrar;
    @FXML
    private VBox vboxEmail;
    @FXML
    private TextField txtEmail;
    @FXML
    private AnchorPane root;
    @FXML
    private TextField txtEmail1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        
        
    }    
    
   
    
    
    
       @FXML
    private void BackRegistro(Event event) throws IOException{
       
        
    Parent BackRegistroParent = FXMLLoader.load(getClass().getResource("/Pantallas/RegistroPacienteFXML.fxml"));
    Scene  BackRegistroScene = new Scene(BackRegistroParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackRegistroScene );
        window.show();
        
    }
    
 
    
     private void AgregarEmail(ActionEvent evento){
        // String nombre = "Email";
        TextField p = new TextField();
        p.setPromptText("Email");
         
         vboxEmail.getChildren().add(p); 
         
         
     }
    
    
     @FXML
    private void Registrar (ActionEvent event) throws IOException{
    Parent RegistrarParent = FXMLLoader.load(getClass().getResource("/Pantallas/ConsultasFXML.fxml"));
    Scene  RegistrarScene = new Scene(RegistrarParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(RegistrarScene);
        window.show();
    }

    @FXML
    private void Control(MouseEvent event) {
    }
    
}
