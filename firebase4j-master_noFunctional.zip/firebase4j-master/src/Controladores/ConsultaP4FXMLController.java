package Controladores;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class ConsultaP4FXMLController implements Initializable {

    @FXML
    private Button BtContinuar;
    @FXML
    private Label titulo;
    @FXML
    private ImageView imgaeBack;
    @FXML
    private Label LblTitulo2;
    @FXML
    private Label LblTitulo3;
    @FXML
    private Label lblFechaInicio;
    @FXML
    private Label lblFechaFin;
    @FXML
    private DatePicker Calendario1;
    @FXML
    private DatePicker Calendario2;
    @FXML
    private Label lblMed;
    @FXML
    private Label lblIndic;
    @FXML
    private TextArea txtMed;
    @FXML
    private TextArea txtInd;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    @FXML
    private void BackPaso3(Event event) throws IOException{
       
        
    Parent BackPaso3= FXMLLoader.load(getClass().getResource("/Pantallas/ConsultasP3FXML.fxml"));
    Scene  BackPaso3Scene = new Scene(BackPaso3);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackPaso3Scene );
        window.show();
    }
    
    @FXML
    private void ConsultaP5(ActionEvent event) throws IOException{
       
        
    Parent ConsultaP5Parent = FXMLLoader.load(getClass().getResource("/Pantallas/ActividadFXML.fxml"));
    Scene  ConsultaP5Scene = new Scene(ConsultaP5Parent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(ConsultaP5Scene  );
        window.show();
    }

   
    
     
    
}
