/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class RegistroPacienteFXMLController implements Initializable {
    
    final ToggleGroup group = new ToggleGroup();
    @FXML
    private Label titulo;
    @FXML
    private ImageView imgaeBack;
    @FXML
    private Label LblTitulo2;
    @FXML
    private Label LblTitulo3;
    @FXML
    private Label SubTitulo1;
    @FXML
    private Label LblPaciente;
    @FXML
    private TextField TxtPaciente;
    @FXML
    private Label LblNombre;
    @FXML
    private TextField txtNombre;
    @FXML
    private Label lblFechaNa;
    @FXML
    private ImageView imageCalendar;
    @FXML
    private Label LblTelefono;
    @FXML
    private Label lblCelular;
    @FXML
    private TextField txtCelular;
    @FXML
    private Label lblGenero;
    @FXML
    private Label LblCity;
    @FXML
    private Label lblDireccion;
    @FXML
    private TextField txtCity;
    @FXML
    private TextArea TxtDireccion;
    @FXML
    private Button BtContinuar;
    @FXML
    private VBox vboxTel;
    @FXML
    private TextField txtTelef;
    @FXML
    private RadioButton btnMasculino;
    @FXML
    private RadioButton btnFem;
    @FXML
    private DatePicker Fecha;
    @FXML
    private TextField txtTelef1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        btnMasculino.setToggleGroup(group);
        btnFem.setToggleGroup(group);
      
       
    }    
    
     @FXML
    private void BackConsulta(Event event) throws IOException{
       
        
    Parent BackConsultaParent = FXMLLoader.load(getClass().getResource("/Pantallas/ConsultasFXML.fxml"));
    Scene  BackConsultaScene = new Scene(BackConsultaParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackConsultaScene );
        window.show();
    }
    
    
    
     @FXML
    private void Continuar (ActionEvent event) throws IOException{
    Parent ContinuarParent = FXMLLoader.load(getClass().getResource("/Pantallas/RegistroP2FXML.fxml"));
    Scene  ContinuarScene = new Scene(ContinuarParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(ContinuarScene );
        window.show();
    }
    
    @FXML
    private void Check(ActionEvent event){
        
        
    }
    
    
    
}
