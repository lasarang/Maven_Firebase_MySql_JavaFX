/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class ConsultasFXMLController implements Initializable {

    //@FXML
    //private AnchorPane AnchorPane;
    @FXML
    private ImageView Image1;
    @FXML
    private Label titulo;
    @FXML
    private Label subtitulo;
    @FXML
    private Label LbNConsulta;
    @FXML
    private Label LbBusqueda;
    @FXML
    private ComboBox<?> Selecion;
    @FXML
    private Label SubTPaciente;
    @FXML
    private TextField TxFCedula;
    @FXML
    private Label LbExisteP;
    @FXML
    private AnchorPane root;
    @FXML
    private ImageView ImageMas;
    @FXML
    private ImageView imgaeBack;
    @FXML
    private ImageView ImagNewPaciente;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
    
      @FXML
    private void BackMenu(Event event) throws IOException{
       
        
    Parent BackMenuParent = FXMLLoader.load(getClass().getResource("/Pantallas/MenuFXML.fxml"));
    Scene  BackMenuScene = new Scene(BackMenuParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackMenuScene );
        window.show();
    }
    
    
    @FXML
    private void IrRegistroPa(Event event) throws IOException{
       
        
    Parent RegistroParent = FXMLLoader.load(getClass().getResource("/Pantallas/RegistroPacienteFXML.fxml"));
    Scene  RegistroScene = new Scene(RegistroParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(RegistroScene );
        window.show();
    }
    
    @FXML
    private void ConsultaP1(Event event) throws IOException{
       
        
    Parent ConsultaP1Parent = FXMLLoader.load(getClass().getResource("/Pantallas/ConsultaPaso1FXML.fxml"));
    Scene  Consultap1Scene = new Scene(ConsultaP1Parent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(Consultap1Scene );
        window.show();
    }
    
}
