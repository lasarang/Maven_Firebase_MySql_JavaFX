/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class ActividadFXMLController implements Initializable {

    @FXML
    private Tab tab1;
    @FXML
    private TextField txtHora;
    @FXML
    private Label lblHora;
    @FXML
    private Label lblCondicion;
    @FXML
    private ComboBox<?> txtCombo;
    @FXML
    private RadioButton btnPresion;
    @FXML
    private RadioButton BtnGlucosa;
    @FXML
    private Label lblMediciones;
    @FXML
    private Label lblMed;
    @FXML
    private ImageView imageGlucosa;
    @FXML
    private ImageView ImagecARDIACO;
    @FXML
    private TableView<?> tableReceta;
    @FXML
    private TableColumn<?, ?> ColumMed;
    @FXML
    private TableColumn<?, ?> ColumPres;
    @FXML
    private TableColumn<?, ?> ColumCantidad;
    @FXML
    private ImageView imageMas;
    @FXML
    private Tab tab2;
    @FXML
    private TableView<?> tableReceta1;
    @FXML
    private TableColumn<?, ?> ColumMed1;
    @FXML
    private TableColumn<?, ?> ColumPres1;
    @FXML
    private TableColumn<?, ?> ColumCantidad1;
    @FXML
    private Tab tab3;
    @FXML
    private TableView<?> tableReceta2;
    @FXML
    private TableColumn<?, ?> ColumMed2;
    @FXML
    private TableColumn<?, ?> ColumPres2;
    @FXML
    private TableColumn<?, ?> ColumCantidad2;
    @FXML
    private Label LblTitulo3;
    @FXML
    private Label LblTitulo2;
    @FXML
    private ImageView imgaeBack;
    @FXML
    private Label titulo;
    @FXML
    private Button BtContinuar;
    @FXML
    private AnchorPane imageGlucosa2;
    @FXML
    private TextField txtHora2;
    @FXML
    private Label lblHora2;
    @FXML
    private Label lblCondicion2;
    @FXML
    private ComboBox<?> combo2;
    @FXML
    private RadioButton radio2Presion;
    @FXML
    private RadioButton radio2Glucosa;
    @FXML
    private Label lblMedciones2;
    @FXML
    private Label subtitulo2;
    @FXML
    private ImageView imagePresion2;
    @FXML
    private ImageView imageMas2;
    @FXML
    private TextField txtHora3;
    @FXML
    private Label lblhora3;
    @FXML
    private Label lblCond3;
    @FXML
    private ComboBox<?> combo3;
    @FXML
    private RadioButton radioPresio3;
    @FXML
    private RadioButton radioGlucosa3;
    @FXML
    private Label lblMedicacion3;
    @FXML
    private Label subtituloMed3;
    @FXML
    private ImageView imageMas3;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    
           @FXML
    private void BackPaso4(Event event) throws IOException{
       
        
    Parent BackPaso4= FXMLLoader.load(getClass().getResource("/Pantallas/ConsultaP4FXML.fxml"));
    Scene  BackPaso4Scene = new Scene(BackPaso4);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackPaso4Scene );
        window.show();
    }
    
     @FXML
    private void ConsultaP6(ActionEvent event) throws IOException{
       
        
    Parent ConsultaP6Parent = FXMLLoader.load(getClass().getResource("/Pantallas/ProximaConsultaFXML.fxml"));
    Scene  ConsultaP6Scene = new Scene(ConsultaP6Parent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(ConsultaP6Scene  );
        window.show();
    }
    
    
    @FXML
    private void VerMed(Event event) throws IOException{
       
        
    Parent VerMedParent = FXMLLoader.load(getClass().getResource("/Pantallas/MedicamentosFXML.fxml"));
    Scene  VerMedScene = new Scene(VerMedParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(VerMedScene  );
        window.show();
    }
    
}
