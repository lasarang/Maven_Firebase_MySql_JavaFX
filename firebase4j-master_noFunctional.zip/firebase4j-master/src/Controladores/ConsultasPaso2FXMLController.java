/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class ConsultasPaso2FXMLController implements Initializable {

    @FXML
    private Button BtContinuar;
    @FXML
    private Label titulo;
    @FXML
    private ImageView imgaeBack;
    @FXML
    private Label LblTitulo2;
    @FXML
    private Label LblTitulo3;
    @FXML
    private Label lblExamen;
    @FXML
    private Label lblProce;
    @FXML
    private TextArea txt2;
    @FXML
    private Label lblDiagnostico;
    @FXML
    private TableView<?> TableDiagnostico;
    @FXML
    private TableColumn<?, ?> Patoligia;
    @FXML
    private TableColumn<?, ?> Antecedentes;
    @FXML
    private TableColumn<?, ?> cie10;
    @FXML
    private TextArea txt1;
    @FXML
    private ImageView ImageMas;
//////////////pantalla emergente////////////////////
     private HBox horizonte;
     
     private VBox centro;
     private Scene NuevaEscena;
     private Stage stage ;
     private BorderPane contenedorP;
     private ComboBox<String> combo_categ ;
     private TextField nbIn;
     
     private  TextField DesIn;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
       @FXML
    private void BackPaso1(Event event) throws IOException{
       
        
    Parent BackPaso1Parent = FXMLLoader.load(getClass().getResource("/Pantallas/ConsultaPaso1FXML.fxml"));
    Scene  BackPaso1Scene = new Scene(BackPaso1Parent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackPaso1Scene);
        window.show();
    }
    
    @FXML
    private void ConsultasP3(ActionEvent event) throws IOException{
       
        
    Parent ConsultasP3Parent = FXMLLoader.load(getClass().getResource("/Pantallas/ConsultasP3FXML.fxml"));
    Scene  ConsultasP3Scene = new Scene(ConsultasP3Parent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(ConsultasP3Scene );
        window.show();
        
    }
    
    @FXML
      private void nuevaVentana(Event evento) {
            
         contenedorP = new BorderPane();
   
       contenedorP = new BorderPane();
       contenedorP.setTop(topBorder());
       contenedorP.setBottom(BottonBorder());
       contenedorP.setCenter(crearCentro());
       
        stage = new Stage();
     
        Scene scene = new Scene(contenedorP,300, 350);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.setTitle("Agregar Diagnostico");
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }
      
     private HBox topBorder(){   // crea los elementos del top de la pagina 
        HBox  topPagina = new HBox();  
        Label  tituloP= new Label("Nuevo Diagnostico");
        tituloP.setAlignment(Pos.CENTER);
        //tituloP.setMaxSize(17, 17);
      // creando el borde superior
      
       tituloP.setPadding(new Insets(5,5,5,5));
       
       
        topPagina.setAlignment(Pos.CENTER);
        topPagina.getChildren().add(tituloP); 
        
        return topPagina;
    }
     
       public Pane crearCentro(){
       centro = new VBox();
       
       HBox texto1 = new HBox();
       HBox texto2 = new HBox();
       HBox texto3 = new HBox();

       Label nb = new Label("Patología"); 
       nbIn = new TextField();
       texto1.getChildren().addAll(nb,nbIn);
      
      
      
       Label Pr = new Label ("Tipo de Antecedentes");
       
       ObservableList<String> opciones = FXCollections.observableArrayList();
       opciones.add("Personal");
       opciones.add("Familiar");
       
        //LUEGO DE ESTO CREAR UN COMBO BOX 
       combo_categ = new ComboBox<>(opciones); 
    

        texto2.getChildren().addAll(Pr,combo_categ);

       Label Des = new Label ("CIE10");
       
       DesIn = new TextField();
       
       DesIn.setMaxSize(100,20);
       
       texto3.getChildren().addAll(Des,DesIn);
        texto1.setSpacing(20);
        texto2.setSpacing(20);
        texto3.setSpacing(20);
        
       
       centro.getChildren().addAll(texto1,texto2,texto3);
       centro.setSpacing(80);
       centro.setPadding(new Insets(20));
       centro.setAlignment(Pos.CENTER);
           
       return centro;
   }
       
       
       public HBox BottonBorder(){
         
         horizonte = new HBox();
         //         botones
       // creacion de botones y posicionamiento
       Button Guardar = new Button("Guardar");
       Guardar.setAlignment(Pos.BOTTOM_LEFT); 
       Guardar.setOnMouseClicked(EventoG ->{
      
                 });
               
       Button Cancelar = new Button("Cancelar");
       Cancelar.setCancelButton(true);
       Cancelar.setAlignment(Pos.BOTTOM_RIGHT);
       Cancelar.setOnMouseClicked(Evento2->{
           stage.close();
       });
       
       // anadir al HBox horizonte que sera la parte inferior del BorderPane
       horizonte.getChildren().addAll(Guardar,Cancelar);
       contenedorP.setPrefSize(400, 400);  // le das un tamano minimo al borderpane
       // aqui se setea el margen o distancia entre los botones cancelar y guardar  y se agrega el Hbox al borderPane
       HBox.setMargin(Guardar,new Insets(0,0,10,10) );
       HBox.setMargin(Cancelar,new Insets(0,0,10,10) );
       horizonte.setAlignment(Pos.CENTER);
       
         return horizonte;
     }
}
