/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author juanjimenez
 */
public class ProximaConsultaFXMLController implements Initializable {

    @FXML
    private Button btSalir;
    @FXML
    private Label LblTtiuloCentral;
    @FXML
    private Label LblTitulo3;
    @FXML
    private Label LblTitulo2;
    @FXML
    private Label LblTitulo1;
    @FXML
    private ImageView ImgBack;
//////////////////////
     private HBox horizonte;
     private VBox centro;
     private Scene NuevaEscena;
     private Stage stage ;
     private BorderPane contenedorP;
     private ComboBox<String> combo_categ ;
     private TextField nbIn;
     
     private  TextArea DesIn;
    @FXML
    private ImageView imageMas;
    @FXML
    private Label AgregarConsulta;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void BackActividades(Event event) throws IOException {
            
    Parent BackActivParent = FXMLLoader.load(getClass().getResource("/Pantallas/ActividadFXML.fxml"));
    Scene  BackActiScene = new Scene(BackActivParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackActiScene);
        window.show();
    }

    @FXML
    private void RegresarMenu(ActionEvent event) throws IOException {
         Parent BackMenuParent = FXMLLoader.load(getClass().getResource("/Pantallas/MenuFXML.fxml"));
         Scene  BackMenuScene = new Scene(BackMenuParent);
    
    //aqui nos da la infomarcion del stage
        Stage window = (Stage)( (Node)event.getSource()).getScene().getWindow();
        window.setScene(BackMenuScene);
        window.show();
    }
    
    @FXML
      private void NuevConsulta(Event evento) {
            
       contenedorP = new BorderPane();
   
       contenedorP = new BorderPane();
       contenedorP.setTop(topBorder());
       contenedorP.setBottom(BottonBorder());
       contenedorP.setCenter(crearCentro());

        stage = new Stage();
       stage.initModality(Modality.APPLICATION_MODAL);
        Scene scene = new Scene(contenedorP,450, 300);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.setTitle("Agregar Cita");
        stage.show();
    }
      
     private HBox topBorder(){   // crea los elementos del top de la pagina 
        HBox  topPagina = new HBox();  
        Label  tituloP= new Label("Nuevo Cita");
      // creando el borde superior
      
       tituloP.setPadding(new Insets(2,2,2,2));
       
       
        topPagina.setAlignment(Pos.CENTER);
        topPagina.getChildren().add(tituloP); 
        
        return topPagina;
    }
     
       public Pane crearCentro(){
       centro = new VBox();
       
       HBox texto1 = new HBox();
       
       HBox texto3 = new HBox();

       Label nb = new Label("Lugar - Fecha y Hora"); 
       nbIn = new TextField();
       texto1.getChildren().addAll(nb,nbIn);
      
     

       Label Des = new Label ("Descripción");
       
       DesIn = new TextArea();
       
       DesIn.setMaxSize(200,100);
       
       texto3.getChildren().addAll(Des,DesIn);
        texto1.setSpacing(80);
        
        texto3.setSpacing(100);
        
       
       centro.getChildren().addAll(texto1,texto3);
       centro.setSpacing(40);
       centro.setPadding(new Insets(20));
       centro.setAlignment(Pos.CENTER);
           
       return centro;
   }
       
       
       public HBox BottonBorder(){
         
         horizonte = new HBox();
         //         botones
       // creacion de botones y posicionamiento
       Button Guardar = new Button("Guardar");
       Guardar.setAlignment(Pos.BOTTOM_LEFT); 
       Guardar.setOnMouseClicked(EventoG ->{
      
                 });
               
       Button Cancelar = new Button("Cancelar");
       Cancelar.setCancelButton(true);
       Cancelar.setAlignment(Pos.BOTTOM_RIGHT);
       Cancelar.setOnMouseClicked(Evento2->{
           stage.close();
       });
       
       // anadir al HBox horizonte que sera la parte inferior del BorderPane
       horizonte.getChildren().addAll(Guardar,Cancelar);
       contenedorP.setPrefSize(400, 400);  // le das un tamano minimo al borderpane
       // aqui se setea el margen o distancia entre los botones cancelar y guardar  y se agrega el Hbox al borderPane
       HBox.setMargin(Guardar,new Insets(0,0,10,10) );
       HBox.setMargin(Cancelar,new Insets(0,0,10,10) );
       horizonte.setAlignment(Pos.CENTER);
       
         return horizonte;
     }

    
    
}
